'use strict';

describe('Tags', () => {
  require('./button');
  require('./caniuse');
  require('./center-quote');
  require('./group-pictures');
  require('./label');
  require('./link-grid');
  require('./mermaid');
  require('./note');
  require('./pdf');
  require('./tabs');
  require('./video');
});
